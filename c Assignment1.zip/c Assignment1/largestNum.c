//    Create an application that prompts a user to enter 3 number. 
//    Create a function that accepts all 3 values and returns the largest of the 3 numbers. 
//    Display the result of the function call using the following format: Largest of num1, num2, num3 is largestNum.

#include <stdio.h>

int LargeNo(int a[2]);
int main(){
    //declaration and initialization
    int num1=0, num2=0, num3=0,valid =0;
    int num[2];
    int ch;
    //accepting Inputs
   while (valid == 0){
       for(int i =0; i <=2; i++){
        puts("Enter Number");
        scanf("%d", &num[i]);
        while ((ch = getchar()) != '\n' && ch != EOF);
        if(num[i] != 0 && num[i] >= 1 )
            valid =1;

       }
    }
    int answer = LargeNo(num);
    printf("The Largest Number Is: %d\n", answer);


    return 0;
}

int LargeNo(int a[2]){
    int max = a[0];
    for(int i=0; i<=2; i++){      
        if (a[i] > max)
        {
            max = a[i];
        }       
    }
    return max;
}