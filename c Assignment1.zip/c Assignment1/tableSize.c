// Create an application for a furniture company which will determine the price of a table. Ask the user to choose 1 for pine, 2 for oak, or 3 for mahogany
// The output is the name of the wood chosen as well as the price of the table.
// Pine tables cost $100, oak tables cost $225, and mahogany tables cost $310.
// If the user enters an invalid wood code, set the price to 0.
// Prompt the user to specify the table size (large or small), but only if the wood selection is valid.
// Add $35 to the price of any large table, and add nothing to the price for a small table. Display an appropriate message if the size value is invalid, and assume the price is for a small table.
// Save the file as TableSize.c

#include <stdio.h>

int main(){
    //declaration and initialization
    int pine=1, oak=2, mahogany=3, userInput=0, selectTable=0;
    double pricePine = 100.00, priceOak=225.00, priceMahogany=310.00, price=0.00, addPrice=35.00;

    //accept input
    puts("choose 1 for pine, 2 for oak, or 3 for mahogany");
    scanf("%d", &userInput);
    int ch; 
    while ((ch = getchar()) != '\n' && ch != EOF);
    //logics
    if(userInput > 3){
          price=price; 
       
    } else if(userInput <= 3){
        switch (userInput)
       {
            case 1:
                price = pricePine;
                break;
            case 2:
                price = priceOak;
                break;
            case 3:
                price = priceMahogany;
                break;     
            default:
                break;
       }
        puts("choose 1 for Large table 2 for Small Table");
        scanf("%d", &selectTable);
        while ((ch = getchar()) != '\n' && ch != EOF);
        if (selectTable == 1){
            addPrice = addPrice;

        }else if(selectTable > 1){
            printf("invalid size selection");
            addPrice=0.0;
        }
    }
      //output  
    printf("\nTotal table price: %f\n", price+addPrice);

    return 0;
}